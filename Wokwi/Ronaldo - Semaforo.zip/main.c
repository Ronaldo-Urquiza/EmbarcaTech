// Retirado de https://github.com/BitDogLab/BitDogLab-C/blob/main/blink/blink.c
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/pwm.h"
#include "hardware/clocks.h"

//Definição de pinos----------------------------------------------
#define LEDVermelho 14
#define LEDAmarelo 11
#define LEDVerde 8
#define LEDVerdePedestre 5

#define pinoBuzzer 2
#define frequenciaBuzzer 2000

const uint pinoBotao = 3; 

//---------------------------------------------------------------

void iniciaLeds(){
  //Inicializa o pino GPIO correspondente ao identificador 
  gpio_init(LEDVermelho);
  gpio_init(LEDAmarelo);
  gpio_init(LEDVerde);
  gpio_init(LEDVerdePedestre);

  //GPIO_SLEW_RATE_SLOW: Reduz a velocidade com que o pino muda de nível lógico (de 0 para 1 ou de 1 para 0).
  gpio_set_slew_rate(LEDVermelho, GPIO_SLEW_RATE_SLOW);
  gpio_set_slew_rate(LEDAmarelo, GPIO_SLEW_RATE_SLOW);
  gpio_set_slew_rate(LEDVerde, GPIO_SLEW_RATE_SLOW);
  gpio_set_slew_rate(LEDVerdePedestre, GPIO_SLEW_RATE_SLOW);

  //gpio_set_dir(pino, direção) no SDK do Raspberry Pi Pico é usada para definir a direção de um pino GPIO como entrada ou saída.
  //true: Define a direção do pino como saída (output)
  //false: Define a direção do pino como entrada (input)
  gpio_set_dir(LEDVermelho, true);
  gpio_set_dir(LEDAmarelo, true);
  gpio_set_dir(LEDVerde, true);
  gpio_set_dir(LEDVerdePedestre, true);
}

void LedSemaforo_Carro(bool r, bool y, bool g){ //Controla os LED's do semáforo 

  gpio_put(LEDVermelho, r);
  gpio_put(LEDAmarelo, y);
  gpio_put(LEDVerde, g);

}

void LedSemaforo_Pedestre(bool g){ //Controla o LED do semáforo

  gpio_put(LEDVerdePedestre, g);

}

void sequenciaSemaforo(){ //Sequencia o Semáforo e Trata o botão

  bool foiApertado = false;

  LedSemaforo_Carro(false, false, true); //Verde aceso
  for(int i = 1; i<=8000; i++){
    
    if(gpio_get(pinoBotao)==0){
        
      foiApertado = true;

      LedSemaforo_Carro(false, true, false); //Amarelo aceso
      for(int i = 1; i<=3000; i++){
        sleep_ms(1);
      }

      break;
    }

    else{
      sleep_ms(1);
    }
  
  }
  
  LedSemaforo_Carro(false, true, false); //Amarelo aceso

    for(int i = 1; i<=2000; i++){

      if(gpio_get(pinoBotao)==0){
        foiApertado = true;
        sleep_ms(5000);
      }
      else{
        sleep_ms(1);
      }
      
    }

  LedSemaforo_Carro(true, false, false); //Vermelho aceso
  if(foiApertado){

    LedSemaforo_Pedestre(true); //Ativa LED do pedestre
    beep(pinoBuzzer, 15000);   //Buzzer ativo por 15 segundos
    LedSemaforo_Pedestre(false); //Desativa LED do pedestre
  }

  else{

    for(int i = 1; i<=10000; i++){

      if(gpio_get(pinoBotao)==0){
        LedSemaforo_Pedestre(true); //Ativa LED do pedestre
        beep(pinoBuzzer, 15000);   //Buzzer ativo por 15 segundos
        LedSemaforo_Pedestre(false); //Desativa LED do pedestre
        break;
      }

      else{
        sleep_ms(1); // Vermelho aceso por 10 segundos sem buzzer
      }

    }

  }

}

void iniciaBotao(){

  gpio_init(pinoBotao); //Iniciando como entrada automaticamente
  gpio_pull_up(pinoBotao); //Configurando como pull_up

}

//BUZZER---------------------------------------------------------------------------------------------------------


// Definição de uma função para inicializar o PWM no pino do buzzer
void pwm_init_buzzer(uint pin) {
    // Configurar o pino como saída de PWM
    gpio_set_function(pin, GPIO_FUNC_PWM);

    // Obter o slice do PWM associado ao pino
    uint slice_num = pwm_gpio_to_slice_num(pin);

    // Configurar o PWM com frequência desejada
    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, clock_get_hz(clk_sys) / (frequenciaBuzzer * 4096)); // Divisor de clock
    pwm_init(slice_num, &config, true);

    // Iniciar o PWM no nível baixo
    pwm_set_gpio_level(pin, 0);
}

// Definição de uma função para emitir um beep com duração especificada
void beep(uint pin, uint duration_ms) {
    // Obter o slice do PWM associado ao pino
    uint slice_num = pwm_gpio_to_slice_num(pin);

    // Configurar o duty cycle para 50% (ativo)
    pwm_set_gpio_level(pin, 1024);

    //NOVO: Ativa led do pedestre 
    LedSemaforo_Pedestre(true);

    // Temporização
    sleep_ms(duration_ms);

    // Desativar o sinal PWM (duty cycle 0)
    pwm_set_gpio_level(pin, 0);

    //NOVO: Desativa led do pedestre
    LedSemaforo_Pedestre(false);

    // Pausa entre os beeps
    sleep_ms(100); // Pausa de 100ms
}


//BUZZER---------------------------------------------------------------------------------------------------------

int main() {

    stdio_init_all();

    iniciaLeds(); 

    iniciaBotao();

    gpio_init(pinoBuzzer);
    gpio_set_dir(pinoBuzzer, true);
    pwm_init_buzzer(pinoBuzzer);

    while (true) {
      
      sequenciaSemaforo(); //SEMAFORO CARRO
 
    }
}